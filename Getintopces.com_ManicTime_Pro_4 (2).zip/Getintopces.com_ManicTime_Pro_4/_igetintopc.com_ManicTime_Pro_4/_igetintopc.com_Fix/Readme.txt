Copy Patch to installation folder and apply it
- do not update until we post updated version on igetintopc.com
- If you still have any problem come to igetintopc.com we sure will try our best to help you out.
- Downloaded from igetintopc.com
Visit Us Daily. Have a nice day
Michelle Williams
igetintopc.com